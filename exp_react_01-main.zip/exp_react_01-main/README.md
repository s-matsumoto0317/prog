## 事前課題
- さいころの数を指定したら、その個数だけさいころをふり、出た目を返却するAPI  
例）curl -X POST -H "Content-Type: application/json" -d "{\"num\":2}" localhost:3001/dice
- おみくじとじゃんけんのAPIも一緒に含まれてます
